#!/bin/bash

/usr/bin/python3 antsocks.py -s

