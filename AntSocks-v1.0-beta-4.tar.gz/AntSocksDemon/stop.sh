#!/bin/bash

/usr/bin/python3 antsocksd.py -q 


